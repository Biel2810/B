print("cubo")

l = float(input("altura/lado: "))

v = l*l*l

#resultado
print('volume = ',v)

result = float(input(" "))
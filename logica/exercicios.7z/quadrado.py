print("Quadrado")

a = float(input("Lado: "))

#area
area = a*a
#perimetro
perimetro = a*4
#resultado
print('Área = ',area)
print('Perímetro = ',perimetro)

result = float(input(" "))

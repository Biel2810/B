print("trapezio")

a = float(input("Lado 1: "))
c = float(input("Lado 2: "))
b = float(input("Base: "))
B = float(input("Base maior: "))
h = float(input("Altura:"))

#perimetro
perimetro = a+b+c+B

#area
area =((B+b)/2)*h

#resultado
print('Área = ',area)
print('Perímetro = ',perimetro)

result = float(input(" "))

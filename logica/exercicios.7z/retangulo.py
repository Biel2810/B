print("retangulo")

a = float(input("Lado 1: "))
b = float(input("Lado 2: "))
#perimetro
perimetro = (2*a)+(2*b)
#area
area = a*b
#resultado
print('Área = ',area)
print('Perímetro = ',perimetro)

result = float(input(" "))
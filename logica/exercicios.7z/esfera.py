print("esfera")

r = float(input("raio: "))

v= (4/3)*3.14*(r*r*r)

#resultado
print('volume = ',v)

result = float(input(" "))
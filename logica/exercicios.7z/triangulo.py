print("Triangulo")

a = float(input("Lado 1: "))
b = float(input("Lado 2: "))
c = float(input("Lado 3: "))
h = float(input("Altura:"))

#perimetro
perimetro = a+b+c

#area
area = (b*h)/2
#resultado
print('Área = ',area)
print('Perímetro = ',perimetro)

result = float(input(" "))

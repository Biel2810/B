print("piramide")

a = float(input("lado: "))
h = float(input("altura: "))

v = ((a*a)*h)/3

#resultado
print('volume = ',v)

result = float(input(" "))
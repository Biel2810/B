print("cilindro")

h = float(input("altura: "))
r = float(input("raio: "))

v = 3.14*(r*r)*h

#resultado
print('volume = ',v)

result = float(input(" "))
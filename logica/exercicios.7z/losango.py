print("losango")

l = float(input("Lado: "))
d = float(input("diagonal menor: "))
D = float(input("diagonal maior: "))

#area
area = (D*d)/2
#perimetro
perimetro = l*4
#resultado
print('Área = ',area)
print('Perímetro = ',perimetro)

result = float(input(" "))

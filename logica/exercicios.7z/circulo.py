print("retangulo")

r = float(input("raio: "))

#perimetro
perimetro = 2*3,14159*r

#area
area = 3,14159*(r*r)

#resultado
print('Área = ',area)
print('Perímetro = ',perimetro)

result = float(input(" "))
